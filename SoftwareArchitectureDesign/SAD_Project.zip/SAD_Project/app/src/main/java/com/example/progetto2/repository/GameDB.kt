package com.example.progetto2.repository


import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import androidx.core.graphics.createBitmap
import androidx.lifecycle.MutableLiveData
import com.example.progetto2.model.Gioco
import com.example.progetto2.model.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

class GameDB {
    companion object{
        private val database = FirebaseDatabase.getInstance().reference
        private val storageRef = FirebaseStorage.getInstance().getReference()
        private val nodoRef = FirebaseDatabase.getInstance().reference
        val x = ArrayList<Bitmap>()

        internal fun getGame(gioco : Gioco, games : MutableLiveData<Gioco>, user : MutableLiveData<User>, pictures : MutableLiveData<ArrayList<Bitmap>>){
            val imagRef = UserDB.getStorageReference().child(gioco?.console.toString() + "/").child(gioco?.key.toString() + "/")
            x.clear()
            x.add(createBitmap(1000,1000))
            x.add(createBitmap(1000,1000))
            x.add(createBitmap(1000,1000))

            val myRef = FirebaseDatabase.getInstance().getReference("Giochi").child(gioco?.console.toString())
            fun loadList(callback: (list: List<Gioco>) -> Unit) {
                myRef.addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onCancelled(snapshotError: DatabaseError) {}
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list : MutableList<Gioco> = mutableListOf()
                        val children = snapshot!!.children
                        children.forEach {
                            list.add(it.getValue(Gioco::class.java)!!)
                        }
                        callback(list)
                    }
                })
            }

            loadList {
                games.value = Gioco(it.get(it.indexOf(gioco!!)).nome,String.format("%d", it[it.indexOf(gioco!!)].prezzo).toInt(),it.get(it.indexOf(gioco!!)).luogo )
            }


            val childEventListener = object : ChildEventListener {
                override fun onChildAdded(dataSnapshot: DataSnapshot, previousChildName: String?) {
                    Log.d(ContentValues.TAG, "onChildAdded:" + dataSnapshot.key!!)

                    val usr = dataSnapshot.getValue(User::class.java)
                    try {
                        user.value = User(usr?.cell, usr?.email)
                    }catch(e : Exception) {}

                }
                override fun onChildChanged(dataSnapshot: DataSnapshot, previousChildName: String?) {
                    Log.d(ContentValues.TAG, "onChildChanged: ${dataSnapshot.key}")
                }

                override fun onChildRemoved(dataSnapshot: DataSnapshot) {
                    Log.d(ContentValues.TAG, "onChildRemoved:" + dataSnapshot.key!!)
                }

                override fun onChildMoved(dataSnapshot: DataSnapshot, previousChildName: String?) {
                    Log.d(ContentValues.TAG, "onChildMoved:" + dataSnapshot.key!!)
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    Log.w(ContentValues.TAG, "postComments:onCancelled", databaseError.toException())
                }
            }
            UserDB.getDatabaseReference().child("users").child(gioco?.id.toString()).child("Dati").addChildEventListener(childEventListener)
            for (i in 0 .. 2){
                downloadFoto(imagRef, pictures, i)
            }
        }

        internal fun loadGame(gioco:Gioco?) : String?{
            val auth = FirebaseAuth.getInstance()
            val id = auth.currentUser?.uid
            //carica il gioco nella lista di tutti i giochi di una piattaforma
            if (id != null && (gioco != null) ) {
                if(gioco?.key==null) {
                    gioco?.key=database.child("Giochi").child(gioco.console!!)
                        .push().key
                }
                database.child("Giochi").child(gioco?.console.toString()).child(gioco?.key.toString()).setValue(
                    Gioco(
                        gioco?.nome,
                        gioco?.prezzo,
                        gioco?.luogo,
                        gioco?.key,
                        id,
                        gioco?.console
                    )
                ) //e nell'area personale dell'utente
                database.child("users").child(id).child("mygames").child(gioco?.key.toString()).setValue(
                    Gioco(
                        gioco?.nome,
                        gioco?.prezzo,
                        gioco?.luogo,
                        gioco?.key,
                        id,
                        gioco?.console
                    )
                )
            }
            return gioco?.key
        }

        internal fun deleteGame(gioco : Gioco?) {
            nodoRef.child("Giochi").child(gioco!!.console.toString()).child(gioco!!.key.toString()).removeValue()
            nodoRef.child("users").child(UserDB.getUid()!!).child("mygames").child(gioco!!.key.toString()).removeValue()
            for (i in 0 .. 2) {
                storageRef.child(gioco?.console.toString() + "/").child(gioco?.key.toString() + "/")
                    .child("picture" + i.toString()).delete()
            }
        }

        private fun downloadFoto(imagRef : StorageReference, pictures : MutableLiveData<ArrayList<Bitmap>>, count : Int) {
            imagRef.child("picture"+count.toString()).getBytes(Long.MAX_VALUE).addOnSuccessListener {
                x.set(count, BitmapFactory.decodeByteArray(it, 0, it.size))
                pictures.value= x
            }.addOnFailureListener {
                // Handle any errors
            }
        }
        //scarica le foto da caricare in fase di modifica, invocata da gameVM
        internal fun downloadFotoEdit(game: Gioco, flag_photo: MutableLiveData<IntArray>,photo_uri: MutableLiveData<ArrayList<Uri>>) {
            var flag= intArrayOf(0,0,0)
            val uri = ArrayList<Uri>()
            photo_uri.value?.clear()
            uri.add(Uri.EMPTY)
            uri.add(Uri.EMPTY)
            uri.add(Uri.EMPTY)
            for (i in 0..2) {
                val imagRef = storageRef.child(game.console + "/").child(game.key + "/")
                imagRef.child("picture" + i.toString()).downloadUrl.addOnSuccessListener {
                    flag[i]=1
                    flag_photo.value=flag //flag che indica l'utilizzo dell'i-esimo imageButton
                    uri.set(i,it)
                    photo_uri.value=uri
                }.addOnFailureListener {
                    // Handle any errors
                }
            }
        }

        internal fun loadPhoto(gioco: Gioco,data:ByteArray,foto_caricate:MutableLiveData<Int>,i : Int) {
            val mountainsRef = storageRef.child(gioco.console!!).child(gioco.key!!).child("picture" + i.toString())
            if(data.isNotEmpty()) {
                val uploadTask = mountainsRef.putBytes(data) //carica i byte della foto
                uploadTask.addOnCompleteListener {
                    var x= foto_caricate.value!!
                    foto_caricate.value=x+1
                }.addOnFailureListener() {
                }
            }
        }
    }
}