package com.example.progetto2.repository

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.progetto2.view.MainActivity
import com.example.progetto2.model.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.lang.Exception

class UserDB {
    companion object{
        private val auth = FirebaseAuth.getInstance()

        internal fun getCurrentUser() : FirebaseUser?{
            return auth.currentUser
        }

        internal fun getInstance() : FirebaseAuth{
            val auth = FirebaseAuth.getInstance()
            return auth
        }

        internal fun getUid() : String? {
            val user = FirebaseAuth.getInstance().currentUser?.uid
            return user
        }

        internal fun getMyRef(user : String?) : DatabaseReference{
            val myRef = FirebaseDatabase.getInstance().getReference("users").child(user.toString())
                .child("Dati")
            return myRef
        }

        internal fun loadUser(myRef : DatabaseReference, utente : MutableLiveData<List<User?>>){
            fun loadList(callback: (list: List<User>) -> Unit) {
                myRef.addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onCancelled(snapshotError: DatabaseError) {}
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val list: MutableList<User> = mutableListOf()
                        val children = snapshot!!.children
                        children.forEach {
                            list.add(it.getValue(User::class.java)!!)
                        }
                        callback(list)
                    }
                })
            }
            loadList {
                try {
                    utente.value = it
                }catch (e: Exception) {}
            }
        }

        internal fun getDatabaseReference() : DatabaseReference{
            val database = FirebaseDatabase.getInstance().reference
            return database
        }
        internal fun getStorageReference() : StorageReference{
            val database = FirebaseStorage.getInstance().getReference()
            return database
        }

        private fun writeNewUser(user : String?, usr : User) {
            val database = getDatabaseReference()
            database.child("users").child(user.toString()).child("Dati").child("Account").setValue(usr)
        }

        internal fun createUserWithEmailAndPassword(email : String, nome : String , cellulare : String , password : String,utente : MutableLiveData<User?>){
            auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(MainActivity()) { task ->
                if (task.isSuccessful) {
                    val user = getUid()
                    utente.value = User(cellulare, email, nome)
                    val usr = User(cellulare, email,nome)
                    writeNewUser(user, usr)
                } else {

                }
            }
        }

        internal fun signIn(email : String, password : String, user : MutableLiveData<FirebaseUser>){
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(MainActivity()) { task ->
                    if (task.isSuccessful) {
                        Log.d("MainActivity", "signInWithEmail:success")
                        user.value = auth.currentUser
                    } else {
                    }
                }
        }
    }


}