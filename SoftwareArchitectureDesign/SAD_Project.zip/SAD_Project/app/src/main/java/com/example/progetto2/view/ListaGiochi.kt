package com.example.progetto2.view

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.example.progetto2.R
import com.example.progetto2.view.RecyclerView.Adapter
import com.example.progetto2.viewmodel.*
import kotlinx.android.synthetic.main.fragment_ps4_list.*


class ListaGiochi : Fragment() {
    //attributi
    private val listVM : ListViewModel by viewModels()
    private val userVM : UserViewModel by viewModels()
    private val navVM : NavigationViewModel by viewModels()
    private val gameVM : GameViewModel by activityViewModels()
    private var category : Int ?=null

    //metodi
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_ps4_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //colora l'actionbar con lo stesso colore della piattaforma scelta e setta il titolo uguale al nome della piattaforma
        category = listVM.getCategory()
        gameVM.select(null)
        setSupportActionBar(category!!)

        //nascondo il bottomNavigation
        val v: View? = activity?.findViewById(R.id.bottomNavigation)
        v?.visibility = View.VISIBLE

        //pulsante per inserimento nuovo gioco
        floatingActionButton.setOnClickListener {
            floatingOnClick(it)
        }
        //visualizzo i separatori tra righe
        lista_giochi.addItemDecoration(
            DividerItemDecoration(
                context,
                LinearLayoutManager.VERTICAL
            )
        )

        // Imposto il layout manager a lineare per avere scrolling in una direzione
        lista_giochi.layoutManager = LinearLayoutManager(activity)

        //Osservo il MutableLiveData del viewModel per aggiornare l'adapter in caso ci siano cambiamenti sulla lista giochi
        listVM.games.observe(viewLifecycleOwner) {
            // update UI
            val adapter = Adapter(it, requireContext(), navVM, gameVM)
            lista_giochi.adapter = adapter
        }
        listVM.getGames()
    }

    private fun setSupportActionBar(category : Int) {
        if (category == 1) {
            (activity as AppCompatActivity).supportActionBar?.setBackgroundDrawable(
                ColorDrawable(
                    Color.parseColor("#004097")
                )
            )
            (activity as AppCompatActivity).supportActionBar?.title = "Playstation"
        }
        if (category == 2) {
            (activity as AppCompatActivity).supportActionBar?.setBackgroundDrawable(
                ColorDrawable(
                    Color.parseColor("#107C10")
                )
            )
            (activity as AppCompatActivity).supportActionBar?.title = "Xbox"
        }
        if (category == 3) {
            (activity as AppCompatActivity).supportActionBar?.setBackgroundDrawable(
                ColorDrawable(
                    Color.parseColor("#DD0001")
                )
            )
            (activity as AppCompatActivity).supportActionBar?.title = "Nintendo"
        }
    }

    //viene invocata nell'activity per effettuare le ricerche (l'activity passa la query come parametro)
    fun domyquery(query: String) {
        listVM.gamesquery.observe(viewLifecycleOwner) {
            // update UI
            val adapter = Adapter(it, requireContext(), navVM, gameVM)
            lista_giochi.adapter = adapter
        }
        listVM.doMyQuery(query)
    }

    private fun floatingOnClick(it : View){
        userVM.navigateBasedOnUser(it,
            R.id.action_ps4_list_to_fragment_inserimento,
            R.id.action_home_to_fragment_impostazioni
        )
    }
}
