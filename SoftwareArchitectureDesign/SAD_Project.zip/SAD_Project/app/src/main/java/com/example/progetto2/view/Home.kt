package com.example.progetto2.view

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import kotlinx.android.synthetic.main.fragment_home.*
import androidx.appcompat.app.AppCompatActivity
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.progetto2.R
import com.example.progetto2.viewmodel.ListViewModel
import com.example.progetto2.viewmodel.NavigationViewModel
import com.example.progetto2.viewmodel.UserViewModel

class Home : Fragment() {
    private val listVM : ListViewModel by viewModels()
    private val userVM : UserViewModel by viewModels()
    private val navVM : NavigationViewModel by viewModels()

    //metodi
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //setto titolo e colore actionBar
        (activity as AppCompatActivity).supportActionBar?.setBackgroundDrawable(ColorDrawable(Color.parseColor("#212121")))
        (activity as AppCompatActivity).supportActionBar?.setTitle("BuyGames")
        //rendo invisibile il bottomNavigation
        val v: View? = activity?.findViewById(R.id.bottomNavigation)
        v?.visibility=View.GONE

        setButtons()
    }

    //visualizzo il menu login o logout in base a  se l'utente è loggato o meno
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        menu?.clear()
        val usr = userVM.getCurrentUser()
        if(usr==null) { //se non è loggato esce login
            inflater?.inflate(R.menu.button_login, menu)
        }
        else { //altrimenti logout
            inflater?.inflate(R.menu.button_logout, menu)
        }
    }

    private fun setButtons() {
        ps4Button.setOnClickListener {
            listVM.setCategory(1)
            navVM.navigate(it, R.id.action_home_to_ps4_list)
        }
        xboxButton.setOnClickListener {
            listVM.setCategory(2)
            navVM.navigate(it, R.id.action_home_to_ps4_list)
        }
        nintendoButton.setOnClickListener {
            listVM.setCategory(3)
            navVM.navigate(it, R.id.action_home_to_ps4_list)
        }
    }
}
