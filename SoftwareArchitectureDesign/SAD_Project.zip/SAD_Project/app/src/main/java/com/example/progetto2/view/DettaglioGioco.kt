package com.example.progetto2.view

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.*
import android.widget.ImageView
import android.widget.Toast
import com.example.progetto2.model.Gioco
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.fragment_dettaglio_gioco.*
import android.view.LayoutInflater
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.example.progetto2.R
import com.example.progetto2.model.User
import com.example.progetto2.viewmodel.GameViewModel
import com.example.progetto2.viewmodel.NavigationViewModel


class DettaglioGioco : androidx.fragment.app.Fragment() {
    //attributi
    private val auth = FirebaseAuth.getInstance()
    private val id = auth.currentUser?.uid.toString()
    private val gameVM : GameViewModel by activityViewModels()
    private val navVM : NavigationViewModel by viewModels()
    val pictures = ArrayList<ImageView>()

    //metodi

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_dettaglio_gioco, container, false)
    }

    //processa voci menu
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item?.itemId) {
            R.id.Cestino -> {
                deleteGame()
            }
            R.id.Modifica -> {
                editGame()
            }
            else -> return false
        }
        return true
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        menu?.clear()
        if (gameVM.getId() == id) {
            inflater?.inflate(R.menu.menu_modifica, menu) //viene mostrato solo il menu modifica
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setHasOptionsMenu(true)
        activity?.requestedOrientation=(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR) //impedisce la rotazione dello schermo
        val v: View? = activity?.findViewById(R.id.bottomNavigation)
        v?.visibility=View.GONE

        pictures.add(picture0)
        pictures.add(picture1)
        pictures.add(picture2)

        setSupportActionBar()

        gameVM.games.observe(viewLifecycleOwner){
            setGame(it)
        }
        gameVM.user.observe(viewLifecycleOwner){
            setUser(it)
        }
        gameVM.pictures.observe(viewLifecycleOwner){
            setPhoto(it)
        }
        gameVM.getGame()

        setButtons()

    }
    
    override fun onDestroy() {
        super.onDestroy()
        activity?.requestedOrientation=(ActivityInfo.SCREEN_ORIENTATION_SENSOR)
    }

    private fun setSupportActionBar() {
        if(gameVM.getConsole()=="Ps4") (activity as AppCompatActivity).supportActionBar?.setBackgroundDrawable(ColorDrawable(Color.parseColor("#004097")))
        if(gameVM.getConsole()=="Xbox") (activity as AppCompatActivity).supportActionBar?.setBackgroundDrawable(ColorDrawable(Color.parseColor("#107C10")))
        if(gameVM.getConsole()=="Nintendo") (activity as AppCompatActivity).supportActionBar?.setBackgroundDrawable(ColorDrawable(Color.parseColor("#DD0001")))
        (activity as AppCompatActivity).supportActionBar?.setTitle("BuyGames")
    }
    private fun setButtons() {
        //invio email
        utente_dettaglio.setOnClickListener {
            //get input from EditTexts and save in variables
            val recipient = utente_dettaglio.text.toString().trim()
            val subject = "BuyGames".trim()
            val message = "Ciao".trim()
            //method call for email intent with these inputs as parameters
            sendEmail(recipient, subject, message)
        }
        //chiamata cell
        cellulare_dettaglio.setOnClickListener {
            val seller = cellulare_dettaglio.text.toString()
            callCell(seller)
        }
        picture0.setOnClickListener {
            zoomFoto(picture0)
        }
        picture1.setOnClickListener {
            zoomFoto(picture1)
        }
        picture2.setOnClickListener {
            zoomFoto(picture2)
        }
    }
    private fun setGame(it : Gioco) {
        nome_dettaglio.text = it.nome
        luogo_dettaglio.text = it.luogo
        val prezzoEuro = String.format("%d", it.prezzo)+"€"
        prezzo_dettaglio.text = prezzoEuro
    }
    private fun setUser(it : User) {
        utente_dettaglio.text = it.email
        cellulare_dettaglio.text = it.cell
    }
    private fun setPhoto(it : ArrayList<Bitmap>) {
        for(i in 0 until it.size) {
            val bitmap = it[i]
            pictures[i].setImageBitmap(bitmap)
        }
    }
    private fun deleteGame() {
        //finestra di dialog per eliminare gioco
        val builder = AlertDialog.Builder(activity as AppCompatActivity)
        builder.setTitle(R.string.AlertMessage)
        builder.setNegativeButton(R.string.NegativeButton,DialogInterface.OnClickListener { _, which -> }) //chiude la finestra
        builder.setPositiveButton(R.string.PositiveButton,DialogInterface.OnClickListener { _, which ->
            gameVM.deleteGame() //elimina il gioco
            navVM.navigateUp(requireView())  //e torna indietro
        })
        builder.show() //mostra la finestra
    }
    private fun editGame() {
        //naviga in inserimento
        navVM.navigate(requireView(), R.id.action_dettaglio_gioco_to_fragment_inserimento)
    }

    //funzione per ingrandire le foto
    private fun zoomFoto(img : ImageView) {
        val dialogBuilder = AlertDialog.Builder(context)
        val inflater = this.layoutInflater
        val dialogView = inflater.inflate(R.layout.foto, null)
        dialogBuilder.setView(dialogView)
        val imageview = dialogView.findViewById(R.id.imageView) as ImageView
        val bitmap = (img.drawable as? BitmapDrawable)?.bitmap
        imageview.setImageBitmap(bitmap)
        val alertDialog = dialogBuilder.create()
        alertDialog.show()
    }

    //Chiama il proprietario gioco (collegamento al dialer)
    private fun callCell(seller : String) {
        val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel",seller,null))
        startActivity(intent)
    }

    //Invia email al proprietario gioco (collegamento gestore email)
    private fun sendEmail(recipient: String, subject: String, message: String) {
        val mIntent = Intent(Intent.ACTION_SEND)
        mIntent.data = Uri.parse("mailto:")
        mIntent.type = "text/plain"
        mIntent.putExtra(Intent.EXTRA_EMAIL,arrayOf(recipient))
        mIntent.putExtra(Intent.EXTRA_SUBJECT, subject)
        mIntent.putExtra(Intent.EXTRA_TEXT, message)
        try {
            startActivity(Intent.createChooser(mIntent, "Choose Email Client..."))
        }
        catch (e: Exception){
            Toast.makeText(context, e.message, Toast.LENGTH_LONG).show()
        }
    }
}
