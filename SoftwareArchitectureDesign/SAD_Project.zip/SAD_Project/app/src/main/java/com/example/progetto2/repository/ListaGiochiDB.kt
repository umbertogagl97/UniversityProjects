package com.example.progetto2.repository

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Bitmap.createBitmap
import android.graphics.BitmapFactory
import android.util.Log
import androidx.core.graphics.createBitmap
import androidx.lifecycle.MutableLiveData
import com.example.progetto2.model.Flag
import com.example.progetto2.model.Gioco
import com.example.progetto2.model.User
import com.google.firebase.database.*
import com.google.firebase.storage.StorageReference
import kotlinx.android.synthetic.main.fragment_dettaglio_gioco.*
import java.net.URL


@Suppress("DEPRECATION")
class ListaGiochiDB {
    companion object {
        val keys = ArrayList<String>()
        val games : ArrayList<Gioco?> = arrayListOf()

        private val database = FirebaseDatabase.getInstance().getReference("Giochi")
        private val database_users = FirebaseDatabase.getInstance().getReference("users")
        private val database_ps4 = database.child("Ps4") //mi serve per leggermi i sottonodi del database
        private val database_xbox = database.child("Xbox")   //mi serve per leggermi i sottonodi del database
        private val database_nintendo = database.child("Nintendo")  //mi serve per leggermi i sottonodi del database

        private fun dbOperations(
            giochi: MutableLiveData<ArrayList<Gioco?>>
        ): ChildEventListener {
            val childEventListener = object : ChildEventListener {
                override fun onChildAdded(dataSnapshot: DataSnapshot, previousChildName: String?) {
                    Log.d(ContentValues.TAG, "onChildAdded:" + dataSnapshot.key!!)
                    // A new comment has been added, add it to the displayed list
                    val g = dataSnapshot.getValue(Gioco::class.java)
                    if (!games.contains(g)) {
                        games.add(g!!)
                        keys.add(dataSnapshot.key.toString()) //aggiungo le varie key in un vettore
                    }
                    giochi.value = games
                }

                override fun onChildChanged(
                    dataSnapshot: DataSnapshot,
                    previousChildName: String?
                ) {
                    Log.d(ContentValues.TAG, "onChildChanged: ${dataSnapshot.key}")
                }

                override fun onChildRemoved(dataSnapshot: DataSnapshot) {
                    Log.d(ContentValues.TAG, "onChildRemoved:" + dataSnapshot.key!!)
                    val g = dataSnapshot.getValue(Gioco::class.java)
                    games.remove(g)
                    giochi.value = games
                }

                override fun onChildMoved(dataSnapshot: DataSnapshot, previousChildName: String?) {
                    Log.d(ContentValues.TAG, "onChildMoved:" + dataSnapshot.key!!)
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    Log.w(
                        ContentValues.TAG,
                        "postComments:onCancelled",
                        databaseError.toException()
                    )
                }
            }
            return childEventListener
        }


        internal fun getGames(giochi : MutableLiveData<ArrayList<Gioco?>>) {
            games.clear()
            val childEventListener = dbOperations(giochi)
           if (Flag.flag == 1) {
                database_ps4.addChildEventListener(childEventListener) //il database da cui chiamo il listener fa variare il sottonodo del database che vado a leggere
            }
            if (Flag.flag == 2) {
                database_xbox.addChildEventListener(childEventListener)
            }
            if (Flag.flag == 3) {
                database_nintendo.addChildEventListener(childEventListener)
            }
        }

        internal fun getMyGames(user : String?, mygames : MutableLiveData<ArrayList<Gioco?>>){
            games.clear()
            val childEventListener = dbOperations(mygames)
            database_users.child(user.toString()).child("mygames")
                .addChildEventListener(childEventListener)

        }

        internal fun doMyQuery(query : String, gamesquery : MutableLiveData<ArrayList<Gioco?>>){
            games.clear()
             val childEventListener = dbOperations(gamesquery)
            if (Flag.flag == 1) {
                database_ps4.orderByChild("luogo").startAt(query).endAt(query+"\uf8ff").addChildEventListener(childEventListener)
                database_ps4.orderByChild("nome").startAt(query).endAt(query+"\uf8ff").addChildEventListener(childEventListener)   //il database da cui chiamo il listener fa variare il sottonodo del database che vado a leggere
            }
            if (Flag.flag == 2) {
                database_xbox.orderByChild("luogo").startAt(query).endAt(query+"\uf8ff").addChildEventListener(childEventListener)
                database_xbox.orderByChild("nome").startAt(query).endAt(query+"\uf8ff").addChildEventListener(childEventListener) //il database da cui chiamo il listener fa variare il sottonodo del database che vado a leggere
            }
            if (Flag.flag == 3) {
                database_nintendo.orderByChild("luogo").startAt(query).endAt(query+"\uf8ff").addChildEventListener(childEventListener)
                database_nintendo.orderByChild("nome").startAt(query).endAt(query+"\uf8ff").addChildEventListener(childEventListener)    //il database da cui chiamo il listener fa variare il sottonodo del database che vado a leggere
            }
        }
    }
}