package com.example.progetto2.viewmodel

import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.progetto2.model.Gioco
import com.example.progetto2.model.User
import com.example.progetto2.repository.GameDB
import com.example.progetto2.repository.ListaGiochiDB
import java.io.ByteArrayOutputStream

class GameViewModel : ViewModel() {
    val games = MutableLiveData<Gioco>()
    val user = MutableLiveData<User>()
    val pictures = MutableLiveData<ArrayList<Bitmap>>()
    val flag_photo = MutableLiveData<IntArray>()
    val photo_uri = MutableLiveData<ArrayList<Uri>>()
    var foto_caricate = MutableLiveData<Int>()


    private var selected : Gioco?=null


    internal fun isNull(): Boolean {
        if (selected == null) {
            return true
        }
        else {
            return false
        }

    }

    internal fun select(item : Gioco?){
        selected = item
    }

    internal fun getNome(): String? {
        return selected?.nome
    }

    internal fun getPrezzo(): Int? {
        return selected?.prezzo
    }

    internal fun getLuogo() : String?{
        return selected?.luogo
    }

    internal fun getConsole(): String? {
        return selected?.console
    }

    internal fun getId(): String? {
        return selected?.id

    }

    internal fun getKey(): String? {
        return selected?.key
    }


    internal fun getGame(){
        GameDB.getGame(selected!!,games,user,pictures)
    }

    internal fun loadGame(nome : String, luogo : String, prezzo : Int, console : String, key : String?) : String?{
        selected = Gioco()
        selected?.nome = nome
        selected?.luogo = luogo
        selected?.prezzo = prezzo.toInt()
        selected?.console = console
        selected?.key = key
        return GameDB.loadGame(selected)
    }

    internal fun downloadFotoEdit() {
        GameDB.downloadFotoEdit(selected!!,flag_photo,photo_uri)
    }

    internal fun loadPhoto(key : String,bitmap : ArrayList<Bitmap>){
        foto_caricate.value=0
        selected!!.key = key
        for (i in 0 until bitmap.size) {
            val baos = ByteArrayOutputStream()
            bitmap?.get(i)?.compress(Bitmap.CompressFormat.JPEG,100, baos)
            val data = baos.toByteArray()
            GameDB.loadPhoto(selected!!,data,foto_caricate,i)
        }
    }

    internal fun deleteGame() {
        GameDB.deleteGame(selected)
    }

}