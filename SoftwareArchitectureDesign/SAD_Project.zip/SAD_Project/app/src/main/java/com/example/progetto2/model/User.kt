package com.example.progetto2.model

data class User ( var cell : String? = null, var email : String? = null, var nome : String? = null )