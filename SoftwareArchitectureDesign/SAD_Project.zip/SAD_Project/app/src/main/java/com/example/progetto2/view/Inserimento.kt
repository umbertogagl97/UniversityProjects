package com.example.progetto2.view

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.appcompat.app.AppCompatActivity
import android.view.*
import android.widget.*
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.example.progetto2.GlideApp
import com.example.progetto2.R
import com.example.progetto2.viewmodel.GameViewModel
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.fragment_fragment_inserimento.*
import java.lang.Exception

class Inserimento : androidx.fragment.app.Fragment(), AdapterView.OnItemSelectedListener {
    //attributi
    val gameVM : GameViewModel by activityViewModels()
    var mod = 0 //indica se il gioco deve essere modificato
    val foto = ArrayList<ImageButton>() //array usato per inserire 3 foto
    var console_spinner : String? = null
    var x = intArrayOf(0,0,0) //usato per sapere quali imagebutton sono stati usati
    var foto_fatte : Int =0
    var REQUEST_IMAGE_CAPTURE = 1 // Costante utilizzata per distinguere l'origine della richiesta della fotocamera

    //metodi

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //aggiungo questa riga per aggiungere un riferimento al menu
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        setHasOptionsMenu(true)
        return inflater.inflate(R.layout.fragment_fragment_inserimento, container, false)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        menu?.clear()
        inflater?.inflate(R.menu.menu_inserimento, menu) //visualizzo solo la spunta per l'inserimento
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        activity?.requestedOrientation=(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR) //impedisce la rotazione dello schermo
        foto.clear()
        //carico l'arraylist con i nomi degli imagebutton
        foto.add(foto1)
        foto.add(foto2)
        foto.add(foto3)

        val v: View? = activity?.findViewById(R.id.bottomNavigation) //ottengo una reference al BottomNavigation
        v?.visibility=View.GONE //e lo rendo invisibile

        //se devo modificare il gioco carico gli oggetti grafici con i valori precedenti
        setValues()
        //settaggio buttons
        setButtons()
        //settaggio spinner
        setSpinner()
    }

    private fun setValues() {
        if (!gameVM.isNull()){
            //modifico il gioco
            mod = 1
            //e mostro nel dettaglio i suoi attributi
            nome_gioco.setText(gameVM.getNome())
            prezzo_gioco.setText(gameVM.getPrezzo().toString())
            luogo_gioco.setText(gameVM.getLuogo())
            spinner.visibility = View.GONE  //nascondo spinner nella modifica
            downloadFoto() //scarico le foto e le inserisco negli imageButton
            (activity as AppCompatActivity).supportActionBar?.setTitle("Modifica gioco") //lascio il colore della console e setto come titolo modifica
        }
        //se non devo modificare il gioco mostro il colore di default e la scritta inserimento
        if(mod!=1) {
            (activity as AppCompatActivity).supportActionBar?.setBackgroundDrawable(ColorDrawable(Color.parseColor("#212121")))
            (activity as AppCompatActivity).supportActionBar?.setTitle("Inserimento gioco")
        }
    }

    //quando si clicca il pulsante inserimento in alto a destra vengono salvati tutti i dati del gioco inseriti
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val nome = nome_gioco.text.toString()
        val luogo = luogo_gioco.text.toString()
        val prezzo = prezzo_gioco.text.toString()
        loadGame(nome,luogo,prezzo)
        return super.onOptionsItemSelected(item)
    }

    //setta lo spinner usato per scegliere la piattaforma del gioco
    private fun setSpinner() {
        val spinner: Spinner = requireActivity().findViewById(R.id.spinner)
        context?.let {
            ArrayAdapter.createFromResource(
                it,
                R.array.console_array,
                android.R.layout.simple_spinner_item
            ).also { adapter ->
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                spinner.adapter = adapter
                spinner.onItemSelectedListener = this
            }
        }
    }

    private fun setButtons() {
        // Imposta il funzionamento dei pulsanti per l'acqisizione dell'immagine
        val takePhoto = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        foto1.setOnClickListener {
            REQUEST_IMAGE_CAPTURE = 1
            // Creo un intent di tipo implicito per acquisire l'immagine
            try {
                startActivityForResult(takePhoto, REQUEST_IMAGE_CAPTURE)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(activity, "Errore", Toast.LENGTH_SHORT).show()
            }
        }
        foto2.setOnClickListener {
            REQUEST_IMAGE_CAPTURE = 2
            try {
                startActivityForResult(takePhoto, REQUEST_IMAGE_CAPTURE)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(activity, "Errore", Toast.LENGTH_SHORT).show()
            }
        }
        foto3.setOnClickListener {
            REQUEST_IMAGE_CAPTURE = 3
            try {
                startActivityForResult(takePhoto, REQUEST_IMAGE_CAPTURE)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(activity, "Errore", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //scarica foto dal database e le inserisce degli ImageButton
    private fun downloadFoto() {
        gameVM.flag_photo.observe(viewLifecycleOwner) {
            x= it
            foto_fatte = x[0] + x[1] + x[2] //tiene conto degli imageButton usati
        }
        gameVM.photo_uri.observe(viewLifecycleOwner) {
            for(i in 0 until it.size) {
                if (it[i]!= Uri.EMPTY) GlideApp.with(this).load(it[i]).into(foto[i])
            }
        }
        gameVM.downloadFotoEdit()
    }

    //Questo metodo viene invocato per gestire il risultato al ritorno da una activity, occorre determinare chi aveva generato la richiesta
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {     // Acquisizione immagine
            val immagineCatturata = data?.extras?.get("data") as Bitmap
            when(REQUEST_IMAGE_CAPTURE){
                1 -> { foto1.setImageBitmap(immagineCatturata) //tiene conto di quante foto caricate
                    x[0]=1 }
                2 -> {
                    foto2.setImageBitmap(immagineCatturata)
                    x[1]=1
                }
                3 -> { foto3.setImageBitmap(immagineCatturata)
                    x[2]=1 }
            }
            if(foto_fatte<3) foto_fatte=x[0]+x[1]+x[2]
        }
    }

    //quando esco dall'inserimento risetto il titolo BuyGames
    override fun onDestroyView() {
        super.onDestroyView()
        (activity as AppCompatActivity).supportActionBar?.setTitle("Buy Games")
        if(mod==0) activity?.requestedOrientation=(ActivityInfo.SCREEN_ORIENTATION_SENSOR)
    }

    //funzione usata per ottenere console dallo spinner se il gioco non è stato modificato ma è stato appena inserito
    private fun getConsole() : String {
        if(mod==0) {
            return console_spinner!!
        }
        else {
            return gameVM.getConsole()!!
        }
    }

    //funzioni usate per gestire lo spinner
    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        console_spinner = parent?.getItemAtPosition(position).toString()
    }
    override fun onNothingSelected(parent: AdapterView<*>?) {
    }

    private fun loadGame(nome : String, luogo : String, prezzo : String){
        if (nome.length > 0 && luogo.length > 0 && prezzo.toInt() > 0) {
            val nullable_key = gameVM.getKey()
            val key = gameVM.loadGame(nome, luogo, prezzo.toInt(), getConsole(),nullable_key)

            if(foto_fatte==0) {
                Navigation.findNavController(requireView()).navigateUp()
                Navigation.findNavController(requireView()).navigateUp()
            }
            else {
                val bitmap= ArrayList<Bitmap>()
                for (i in 0..2) {
                    if(x[i]==1) bitmap.add((foto[i].drawable as? BitmapDrawable)!!.bitmap)
                }
                gameVM.foto_caricate.observe(viewLifecycleOwner) {
                    //se è l'ultima
                    if (it == foto_fatte) {
                        Navigation.findNavController(requireView()).navigateUp()
                        if (mod == 1) {
                            Navigation.findNavController(requireView()).navigateUp()
                        }
                    }
                }
                gameVM.loadPhoto(key!!,bitmap)
            }

            //se ci sono foto da caricare
        }
        else Toast.makeText(activity, "Hai mancato qualche campo", Toast.LENGTH_SHORT).show()
    }
}

