package com.example.progetto2.viewmodel

import android.content.SharedPreferences
import android.view.View
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.navigation.Navigation
import com.example.progetto2.model.User
import com.example.progetto2.repository.UserDB
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

class UserViewModel : ViewModel() {
    //Questa variabile mi serve per caricare i dati nell'area personale
    val utente = MutableLiveData<List<User?>>()
    //Questa variabile mi serve per notificare la view NewAccount che un nuovo usr è stato creato
    val usr = MutableLiveData<User?>()
    //Questa variabile mi serve per notificare la view Login che un nuovo utente si è loggato
    val fireUser = MutableLiveData<FirebaseUser>()
    val username = MutableLiveData<String>()
    val password = MutableLiveData<String>()
    val autologin = MutableLiveData<Boolean>()

    private val PREF_NAME = "Vendita-videogiochi"      // Nome del file
    private val PREF_USERNAME = "Username"
    private val PREF_PASSWORD = "Password"
    private val PREF_AUTOLOGIN = "AutoLogin"

    internal fun navigateBasedOnUser(view : View, fragment1 : Int, fragment2 : Int){
        val currentUser = UserDB.getCurrentUser()
        if (currentUser != null) {
            Navigation.findNavController(view)
                .navigate(fragment1)
        } else {
            Navigation.findNavController(view).navigate(fragment2)
        }
    }

    internal fun navigateBasedOnUser(view : View, fragment1 : Int){
        val currentUser = UserDB.getCurrentUser()
        if (currentUser == null) {
            Navigation.findNavController(view).navigateUp()
            Navigation.findNavController(view).navigate(fragment1)
        }
    }

    internal fun dataUser() {
        val user = UserDB.getUid()
        val myRef =  UserDB.getMyRef(user)
        UserDB.loadUser(myRef,utente)
    }

    internal fun getCurrentUser() : FirebaseUser?{
        val usr = FirebaseAuth.getInstance().currentUser
        return usr
    }

    internal fun createAccount(email : String, nome : String , cellulare : String , password : String){
        UserDB.createUserWithEmailAndPassword(email,nome,cellulare,password,usr)

    }

    internal fun signIn(email : String, password : String){
        UserDB.signIn(email, password, fireUser)
    }


    //verifica se i campi sono stati riempiti correttamente
    internal fun verificacampi(email : String, nome : String , cellulare : String , password : String) : Boolean{
        return email.isNotEmpty() && password.isNotEmpty() && nome.isNotEmpty() && cellulare.isNotEmpty()
    }

    internal fun verificacampi(email : String, password : String) : Boolean{
        return email.isNotEmpty() && password.isNotEmpty()
    }

    internal fun leggiDatiLogin(sharedPref: SharedPreferences){
        username.value = sharedPref.getString(PREF_USERNAME, "")
         password.value = sharedPref.getString(PREF_PASSWORD,"")
         autologin.value = sharedPref.getBoolean(PREF_AUTOLOGIN, false)

    }

    internal fun salvaDatiLogin(sharedPref: SharedPreferences, username : String, password : String, autoLogin : Boolean) {
        val editor = sharedPref.edit()

        editor.putString(PREF_USERNAME, username)
        editor.putString(PREF_PASSWORD,password)
        editor.putBoolean(PREF_AUTOLOGIN, autoLogin)
        editor.apply()    // Salva le modifiche
    }

}