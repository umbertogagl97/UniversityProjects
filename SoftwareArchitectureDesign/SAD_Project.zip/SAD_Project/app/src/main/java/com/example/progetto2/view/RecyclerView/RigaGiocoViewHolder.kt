package com.example.progetto2.view.RecyclerView

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.riga.view.*

class RigaGiocoViewHolder(view: View) : androidx.recyclerview.widget.RecyclerView.ViewHolder(view) {
    var Nome = view.nome
    var Prezzo = view.Prezzo
    var Luogo = view.Luogo
    var Immagine = view.game_picture
}