package com.example.progetto2

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.appcompat.app.AppCompatActivity
import android.util.Log
import android.view.*
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import com.example.progetto2.viewmodel.NavigationViewModel
import com.example.progetto2.viewmodel.UserViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.android.synthetic.main.fragment_fragment_login.*

class Login : Fragment() {
    //aatributi
    private val userVM : UserViewModel by viewModels()
    private val navVM : NavigationViewModel by viewModels()
    // Chiavi nelle preferenze
    private val PREF_NAME = "Vendita-videogiochi"      // Nome del file
    private lateinit var sharedPref: SharedPreferences

    //metodi

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //aggiungo questa riga per aggiungere un riferimento al menu
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_fragment_login, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //setto titolo e colore dell'actionbar
        setGraphics()

        sharedPref = requireActivity().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

        userVM.autologin.observe(viewLifecycleOwner){
            chkAutoLogin.isChecked = it
        }
        userVM.username.observe(viewLifecycleOwner){
            email.setText(it)
        }
        userVM.password.observe(viewLifecycleOwner){
            password.setText(it)
        }
        userVM.leggiDatiLogin(sharedPref)

        setButtons()
    }

    private fun setGraphics() {
        (activity as AppCompatActivity).supportActionBar?.setBackgroundDrawable(ColorDrawable(Color.parseColor("#212121")))
        (activity as AppCompatActivity).supportActionBar?.setTitle("Login")
        //nascondo il bottomNavigation
        val v: View? = activity?.findViewById(R.id.bottomNavigation)
        v?.visibility = View.GONE
    }

    private fun tryLogin() {
        if (userVM.verificacampi(email.text.toString(), password.text.toString())) {
            userVM.salvaDatiLogin(sharedPref,email.text.toString(), password.text.toString(), chkAutoLogin.isChecked)
            signIn(email.text.toString(), password.text.toString())
        } else {
            Toast.makeText(activity, "Email o password troppo breve", Toast.LENGTH_SHORT).show()
        }
    }

    //questa funzione rende invisibile il menu nel fragment impostazioni
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        menu?.clear()
    }

    private fun setButtons() {
        //provo a effettuare il login
        btnConferma.setOnClickListener {
            tryLogin()
        }
        newaccountbtn.setOnClickListener {
            //naviga al fragment newAccount
            navVM.navigate(it,R.id.action_fragment_login_to_newaccount)
        }
    }

    //funzione usata per effettuare il login
    private fun signIn(email: String, password: String) {
        userVM.fireUser.observe(viewLifecycleOwner){
            Toast.makeText(activity, "Utente loggato", Toast.LENGTH_LONG).show()
            navVM.navigateUp(requireView())
        }
        userVM.signIn(email,password)
    }

}