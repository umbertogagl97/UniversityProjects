package com.example.progetto2.view

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.*
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.example.progetto2.R
import com.example.progetto2.model.Gioco
import com.example.progetto2.model.User
import com.example.progetto2.view.RecyclerView.Adapter
import com.example.progetto2.viewmodel.*
import kotlinx.android.synthetic.main.fragment_area_personale.*
import java.lang.Exception

class AreaPersonale : androidx.fragment.app.Fragment() {
    //attributi
    private val listVM : ListViewModel by viewModels()
    private val userVM : UserViewModel by viewModels()
    private val navVM : NavigationViewModel by viewModels()
    private val gameVM : GameViewModel by activityViewModels()
    private var cont : Int ?=null
    //metodi

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_area_personale, container, false)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
            menu?.removeItem(R.id.app_bar_search) //rimuove l'action bar dall'area personale
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        activity?.requestedOrientation=(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR) //impedisce la rotazione dello schermo
        super.onViewCreated(view, savedInstanceState)
        //setto colore e titolo dell'action bar
        gameVM.select(null)

        setGraphics()

        //Se l'utente non è loggato, vado al fragment di login e il resto del codice non verrà eseguito
        userVM.navigateBasedOnUser(view,R.id.action_home_to_fragment_impostazioni)

        //Se invece l'utente è loggato esegui il seguente codice
        val v: View? = activity?.findViewById(R.id.bottomNavigation)
        v?.visibility=View.VISIBLE
        // Imposto il layout manager a lineare per avere scrolling in una direzione
        lista_mieigiochi.layoutManager =
            androidx.recyclerview.widget.LinearLayoutManager(activity)

        //setta la textView annunci col valore di cont, inizialmente a 0
        cont=0 //contatore di righe inserite nella recycleView
        setCont(cont!!)
        listVM.mygames.observe(viewLifecycleOwner) {
            // update UI
            setGames(it)
            cont = it.size
            setCont(cont!!)
        }
        listVM.getMyGames()

        userVM.utente.observe(viewLifecycleOwner){
            setUser(it)
        }
        userVM.dataUser()


    }
    private fun setUser(it : List<User?>) {
        try {
            email.text = it[0]?.email.toString()
            cell.text = it[0]?.cell.toString()
        }catch (e: Exception) {}
    }

    private fun setGames(it : ArrayList<Gioco?>) {
        val adapter = Adapter(it, requireContext(), navVM, gameVM)
        lista_mieigiochi.adapter = adapter
    }

    private fun setCont(cont : Int) {
        try { annunci.text=cont.toString() }catch(e:Exception) {}
    }

    private fun setGraphics() {
        (activity as AppCompatActivity).supportActionBar?.setBackgroundDrawable(ColorDrawable(Color.parseColor("#212121")))
        (activity as AppCompatActivity).supportActionBar?.title="Area personale"
        //divide le varie righe della recycleView
        lista_mieigiochi.addItemDecoration(
            androidx.recyclerview.widget.DividerItemDecoration(
                context,
                androidx.recyclerview.widget.LinearLayoutManager.VERTICAL
            )
        )
    }

    //quando lascio il fragment abilito la rotazione
    override fun onDestroyView() {
        super.onDestroyView()
        activity?.requestedOrientation=(ActivityInfo.SCREEN_ORIENTATION_SENSOR)
    }
}
