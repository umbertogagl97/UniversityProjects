package com.example.progetto2.viewmodel

import android.view.View
import androidx.lifecycle.ViewModel
import androidx.navigation.Navigation
import com.example.progetto2.R

class NavigationViewModel : ViewModel() {

    internal fun navigate(view : View, fragment : Int){
        Navigation.findNavController(view).navigate(fragment)
    }

    internal fun navigateUp(view : View){
        Navigation.findNavController(view).navigateUp()
    }
}