package com.example.progetto2.viewmodel


import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.progetto2.model.Flag
import com.example.progetto2.model.Gioco
import com.example.progetto2.repository.ListaGiochiDB
import com.google.firebase.auth.FirebaseAuth

class ListViewModel : ViewModel(){

    val games = MutableLiveData<ArrayList<Gioco?>>()
    val mygames = MutableLiveData<ArrayList<Gioco?>>()
    val gamesquery = MutableLiveData<ArrayList<Gioco?>>()


    internal fun getCategory() : Int{
        return Flag.flag
    }
    internal fun setCategory(category : Int){
        Flag.flag = category
    }


    internal fun getGames() {
        ListaGiochiDB.getGames(games)
    }
    internal fun getMyGames(){
        val user = FirebaseAuth.getInstance().currentUser?.uid
        //Nota: tale metodo dovrà essere invocato soltanto nelle sezioni di codice in cui si è sicuri che l'utente sia loggato
        ListaGiochiDB.getMyGames(user, mygames)
    }
    internal fun doMyQuery(query : String) {
        ListaGiochiDB.doMyQuery(query,gamesquery)
    }




}