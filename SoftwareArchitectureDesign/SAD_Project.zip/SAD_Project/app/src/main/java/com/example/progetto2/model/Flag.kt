package com.example.progetto2.model



object Flag{

    var flag : Int=0

}