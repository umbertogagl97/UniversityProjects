package com.example.progetto2.view

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.*
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import com.example.progetto2.R
import com.example.progetto2.viewmodel.UserViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.fragment_newaccount.*

class NewAccount : androidx.fragment.app.Fragment() {
    //attributi
    private val userVM : UserViewModel by viewModels()

    //metodi

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setto il titolo dell'actionBar
        (activity as AppCompatActivity).supportActionBar?.setTitle("New Account")
        //aggiungo questa riga per aggiungere un riferimento al menu
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_newaccount, container, false)
    }

    //Rende invisibile
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        menu?.clear()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setGraphics()

        //operazione da effettuare quando si clicca su conferma
        btnConferma.setOnClickListener{
            tryCreateAccount()
        }
    }

    private fun setGraphics() {
        //setto titolo e colore dell'actionBar
        (activity as AppCompatActivity).supportActionBar?.setBackgroundDrawable(ColorDrawable(Color.parseColor("#212121")))
        (activity as AppCompatActivity).supportActionBar?.setTitle("Creazione account")
        //rendo invisibile il bottomNavigation
        val v: View? = activity?.findViewById(R.id.bottomNavigation)
        v?.visibility=View.GONE
    }

    private fun tryCreateAccount() {
        if (userVM.verificacampi(email.text.toString(),nome.text.toString(),cellulare.text.toString(), password.text.toString())) {
            userVM.usr.observe(viewLifecycleOwner){
                Toast.makeText(context, "Utente registrato con successo", Toast.LENGTH_SHORT).show()
                //torno direttamente alla lista giochi e non al login
                Navigation.findNavController(requireView()).navigateUp()
                Navigation.findNavController(requireView()).navigateUp()
            }
            userVM.createAccount(email.text.toString(),nome.text.toString(),cellulare.text.toString(), password.text.toString())
        }
        else{
            Toast.makeText(activity,"Email o password troppo breve",Toast.LENGTH_SHORT).show()
        }
    }
}
